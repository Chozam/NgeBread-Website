let order = document.getElementsByClassName("order");
order.addEvenListener("click", function(){
    alert("Thanks for your order:>");
})